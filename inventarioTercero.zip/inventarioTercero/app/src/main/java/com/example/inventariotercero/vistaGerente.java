package com.example.inventariotercero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import interfaces_gerente.Adapter;
import interfaces_gerente.Usuarios;
import interfaces_gerente.agregar_gerente;
import interfaces_gerente.buscar_gerente;


public class vistaGerente extends AppCompatActivity {

    ImageButton imbtnAgregar, imbtnBuscar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_gerente);

        imbtnAgregar = findViewById(R.id.imbtnAgregar);
        imbtnBuscar = findViewById(R.id.imbtnEmpleados);

        //onclick de listar empleados
        imbtnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVentanaBuscar();
            }
        });



        //Onclick de boton agregar
        imbtnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVentanaAgregar();
            }
        });
    }

    public void abrirVentanaAgregar(){
        Intent i=new Intent(this, agregar_gerente.class);
        startActivity(i);
    }

    public void abrirVentanaBuscar() {
        Intent intent = new Intent(this, buscar_gerente.class);
        startActivity(intent);
    }

}