package interfaces_gerente;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.inventariotercero.R;

import java.util.HashMap;
import java.util.Map;

public class agregar_gerente extends AppCompatActivity {

    EditText etIdMain, etUsuarioMain, etPss;
    Spinner spinner;
    Button btnAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_gerente);

        etIdMain= findViewById(R.id.etIdDatos);
        etUsuarioMain=findViewById(R.id.etEditarUsuarioDatos);
        etPss=findViewById(R.id.etEditarPssDatos);
        btnAgregar=findViewById(R.id.btnAgregar);


        spinner=findViewById(R.id.spinnerDatos);
        String[] opciones={"Gerente", "Productor","Vendedor"};
        ArrayAdapter<String>adapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,opciones);
        spinner.setAdapter(adapter);

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarUsuario("http://192.168.128.36/bdInventario/agregar_usuario.php");
            }
        });
    }

    private void agregarUsuario(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
                etIdMain.setText("");
                etUsuarioMain.setText("");
                etPss.setText("");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("idUsuario", etIdMain.getText().toString());
                parametros.put("usuUsuario", etUsuarioMain.getText().toString());
                parametros.put("pssUsuario", etPss.getText().toString());
                parametros.put("cargoUsuario", spinner.getSelectedItem().toString());
                return parametros;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}