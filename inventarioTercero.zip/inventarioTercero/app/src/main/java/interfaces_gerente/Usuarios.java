package interfaces_gerente;

public class Usuarios {
    private String id;
    private String usuario;
    private String contra;
    private String cargo;

    public Usuarios(String id, String usuario, String contra, String cargo) {
        this.id = id;
        this.usuario = usuario;
        this.contra = contra;
        this.cargo = cargo;
    }

    public String getId() {
        return id;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContra() {
        return contra;
    }

    public String getCargo() {
        return cargo;
    }
}


