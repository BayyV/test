package interfaces_gerente;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import com.example.inventariotercero.R;

import java.util.List;

public class Adapter extends ArrayAdapter<Usuarios> {

    private Context context;
    private List<Usuarios> usuariosList;

    public Adapter(@NonNull Context context, List<Usuarios> usuariosList) {
        super(context, R.layout.list_usuarios, usuariosList);
        this.context = context;
        this.usuariosList = usuariosList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_usuarios, parent, false);
        }

        TextView tvid = convertView.findViewById(R.id.txt_id);
        TextView tvUsuario = convertView.findViewById(R.id.txt_name);

        Usuarios usuario = usuariosList.get(position);

        tvid.setText(usuario.getId());
        tvUsuario.setText(usuario.getUsuario());

        return convertView;
    }
}

