package interfaces_gerente;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.inventariotercero.R;

import org.json.JSONException;
import org.json.JSONObject;

public class rud_gerente extends AppCompatActivity {

    EditText etIdDatos, etEditarUsuario, etEditarPss;
    Spinner spinerDatos;

    Button btnBuscarMain, btnModificarMain, btnBorrarMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rud_gerente);

        etIdDatos = findViewById(R.id.etIdDatos);
        etEditarUsuario = findViewById(R.id.etEditarUsuarioDatos);
        etEditarPss = findViewById(R.id.etEditarPssDatos);

        btnBuscarMain = findViewById(R.id.btnBuscarDatos);
        btnModificarMain = findViewById(R.id.btnModificarDatos);
        btnBorrarMain = findViewById(R.id.btnEliminarDatos);

        spinerDatos = findViewById(R.id.spinnerDatos);

        String[] opciones = {"Gerente", "Productor", "Vendedor"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        spinerDatos.setAdapter(adapter);

        btnBuscarMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idUsuario = etIdDatos.getText().toString();
                buscarUsuario(idUsuario);
            }
        });
    }

    public void buscarUsuario(String idUsuario) {
        String url = "http://192.168.128.36/bdInventario/buscar1.php";

        // Crear una solicitud GET con el parámetro idUsuario
        StringRequest request = new StringRequest(Request.Method.GET, url + "?idUsuario=" + idUsuario,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Procesar la respuesta JSON
                            JSONObject jsonObject = new JSONObject(response);
                            int exito = jsonObject.getInt("exito");

                            if (exito == 1) {
                                // Usuario encontrado
                                JSONObject datosUsuario = jsonObject.getJSONObject("datos");
                                mostrarDatosUsuario(datosUsuario);
                            } else {
                                // No se encontró el usuario
                                Toast.makeText(rud_gerente.this, "Usuario no encontrado", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(rud_gerente.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Manejar errores de la solicitud
                Toast.makeText(rud_gerente.this, "Error en la solicitud", Toast.LENGTH_SHORT).show();
            }
        });

        // Agregar la solicitud a la cola y ejecutarla
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void mostrarDatosUsuario(JSONObject datosUsuario) throws JSONException {
        // Mostrar los datos en los EditText
        etEditarUsuario.setText(datosUsuario.getString("usuUsuario"));
        etEditarPss.setText(datosUsuario.getString("pssUsuario"));

        // Obtener el cargo del usuario
        String cargoUsuario = datosUsuario.getString("cargoUsuario");

        // Seleccionar automáticamente el valor del Spinner
        int posicion = obtenerPosicionCargo(cargoUsuario);
        spinerDatos.setSelection(posicion);
    }

    private int obtenerPosicionCargo(String cargo) {
        // Obtener la posición del cargo en el array de opciones
        for (int i = 0; i < spinerDatos.getCount(); i++) {
            if (spinerDatos.getItemAtPosition(i).equals(cargo)) {
                return i;
            }
        }
        return 0; // Si no se encuentra, selecciona el primer elemento
    }
}

