package interfaces_gerente;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.inventariotercero.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class buscar_gerente extends AppCompatActivity {

    private ListView listView;
    private Adapter adapter;
    private ArrayList<Usuarios> buscar_gerentesArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_gerente);

        listView = findViewById(R.id.lvMostrarDatos);
        adapter = new Adapter(this, buscar_gerentesArrayList);
        listView.setAdapter(adapter);

        ListarDatos();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(buscar_gerente.this, rud_gerente.class);
                startActivity(intent);
            }
        });
    }

    public void agregar(View view) {
        Intent intent = new Intent(buscar_gerente.this, agregar_gerente.class);
        startActivity(intent);
    }


    public void ListarDatos() {
        String url = "http://192.168.128.36/bdInventario/buscar_usuario.php";

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                buscar_gerentesArrayList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String exito = jsonObject.getString("exito");

                    if (exito.equals("1")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("datos");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String id = object.getString("idUsuario");
                            String nombre = object.getString("usuUsuario");
                            String contrasena = object.getString("pssUsuario");
                            String cargo = object.getString("cargoUsuario");

                            Usuarios usuarios = new Usuarios(id, nombre, contrasena, cargo);
                            buscar_gerentesArrayList.add(usuarios);
                        }

                        // Notifica al adaptador después de agregar los elementos al ArrayList
                        adapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(buscar_gerente.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Manejar errores de la solicitud
                Toast.makeText(buscar_gerente.this, "Error en la solicitud: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Agrega la solicitud a la cola y ejecútala
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }


}

